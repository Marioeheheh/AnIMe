# game-naruto-run-javascript
 simple game - infinite run in javascript
